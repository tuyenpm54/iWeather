//
//  GlobalVariable.swift
//  iPOSOrder
//
//  Created by iPOS on 4/22/15.
//  Copyright (c) 2015 iPOS. All rights reserved.
//

import Foundation

struct GlobalVariable {
    
    static var hostURL = "http://192.168.1.109/pdaservice/service.svc"
    static var listFood = [Food]()
    static var listArea = [Area]()
    static var listUser = [UserN]()
}