//
//  Area.swift
//  iPOS_Order
//
//  Created by iPOS on 4/20/15.
//  Copyright (c) 2015 iPOS. All rights reserved.
//

import Foundation

class Area {
    var AreaId: String = ""
    var AreaName: String = ""
    
    init(id: String, name: String) {
        AreaId = id
        AreaName = name
    }
}