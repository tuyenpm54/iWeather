//
//  PKHUD.h
//  PKHUD
//
//  Created by Philip Kluz on 6/17/14.
//  Copyright (c) 2014 NSExceptional. All rights reserved.
//

@import UIKit;

//! Project version number for PKHUD.
FOUNDATION_EXPORT double PKHUDVersionNumber;

//! Project version string for PKHUD.
FOUNDATION_EXPORT const unsigned char PKHUDVersionString[];
